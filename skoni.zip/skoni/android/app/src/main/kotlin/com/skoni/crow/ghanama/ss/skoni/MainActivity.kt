package com.skoni.crow.ghanama.ss.skoni

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
