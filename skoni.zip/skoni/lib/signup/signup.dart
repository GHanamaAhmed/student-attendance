import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class Signup extends StatefulWidget {
  const Signup({Key? key}) : super(key: key);

  @override
  State<Signup> createState() => _SignupState();
}

class _SignupState extends State<Signup> with TickerProviderStateMixin {
  late AnimationController controller;
  late Animation<Offset> offset;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    controller = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 200));

    offset = Tween<Offset>(begin: const Offset(1.0, 0.0), end: Offset.zero)
        .animate(controller);
    controller.forward();
  }

  static var url =
      Uri.parse("https://simpleapi-p29y.onrender.com/users/signup");
  bool passwordvisible = true;
  final TextEditingController _controller = new TextEditingController();
  final TextEditingController _controller1 = new TextEditingController();
  final TextEditingController _controller2 = new TextEditingController();
  final TextEditingController _controller3 = new TextEditingController();
  final TextEditingController _controller4 = new TextEditingController();
  bool validateEmail(email) {
    return RegExp(
            r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+")
        .hasMatch(email);
  }

  Future<dynamic> signup() async {
    if (_controller.text.isEmpty ||
        _controller1.text.isEmpty ||
        _controller4.text.isEmpty ||
        _controller2.text.isEmpty ||
        _controller3.text.isEmpty) {
      return (showDialog<String>(
          context: context,
          builder: (BuildContext context) => AlertDialog(
                title: const Text('Worring'),
                content: Text("Enter all data please"),
                actions: <Widget>[
                  TextButton(
                    onPressed: () => Navigator.pop(context, 'Cancel'),
                    child: const Text('Cancel'),
                  )
                ],
              )));
    } else if (_controller1.text.toString() != _controller4.text.toString()) {
      return (showDialog<String>(
          context: context,
          builder: (BuildContext context) => AlertDialog(
                title: const Text('Worring'),
                content: Text("Enter the same password"),
                actions: <Widget>[
                  TextButton(
                    onPressed: () => Navigator.pop(context, 'Cancel'),
                    child: const Text('Cancel'),
                  )
                ],
              )));
    }
    showDialog(
      context: context,
      builder: (context) {
        return Center(
          child: CircularProgressIndicator(),
        );
      },
    );
    var respose = await http.post(url, headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
    }, body: {
      "firstname": _controller2.text.toString(),
      "lastname": _controller3.text.toString(),
      "email": _controller.text.toString(),
      "password": _controller1.text.toString()
    });
    var deres = jsonDecode(respose.body);
    Navigator.of(context).pop();
    if (!deres["res"]) {
      return (showDialog<String>(
          context: context,
          builder: (BuildContext context) => AlertDialog(
                title: const Text('Worring'),
                content: Text(deres["mes"]),
                actions: <Widget>[
                  TextButton(
                    onPressed: () => Navigator.pop(context, 'Cancel'),
                    child: const Text('Cancel'),
                  )
                ],
              )));
    }
  }
  bool validatetText(text) {
    return RegExp(r"^[a-zA-Z]+").hasMatch(text);
  }
  int emailClick = 0;
  int firstName = 0;
  int lasttName = 0;
  int password = 0;
  int resetPasword = 0;
  bool checkbox = false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.white,
        body: SlideTransition(
          position: offset,
          child: Center(
            child: FractionallySizedBox(
              widthFactor: 0.8,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          "Sign up",
                          style: TextStyle(
                              fontSize: 40,
                              fontWeight: FontWeight.bold,
                              color: Colors.blueAccent),
                        )
                      ],
                    ),
                  ),
                  Container(
                    child: Row(
                      children: [
                        Expanded(
                          flex: 1,
                          child: Container(
                            margin: EdgeInsets.fromLTRB(0, 10, 2, 10),
                            child: TextFormField(
                              onTap: () {
                                setState(() {
                                  firstName = 1;
                                });
                              },
                              controller: _controller2,
                              onChanged: (value) => setState(() {}),
                              decoration: InputDecoration(
                                  suffixIcon: _controller2.text.length > 0
                                      ? IconButton(
                                          onPressed: () {
                                            _controller2.clear();
                                            setState(() {});
                                          },
                                          icon: Icon(Icons.clear),
                                        )
                                      : null,
                                  enabledBorder: OutlineInputBorder(
                                      borderSide: validatetText(_controller2
                                                  .text
                                                  .toString()) ||
                                              firstName == 0
                                          ? BorderSide.none
                                          : BorderSide(
                                              color: Colors.redAccent,
                                              width: 2)),
                                  border: OutlineInputBorder(
                                      borderSide: validatetText(_controller2
                                                  .text
                                                  .toString()) ||
                                              firstName == 0
                                          ? BorderSide(
                                              color: Colors.blueAccent,
                                              width: 2)
                                          : BorderSide(
                                              color: Colors.redAccent,
                                              width: 2)),
                                  filled: true,
                                  hintStyle: TextStyle(
                                      color: Color.fromRGBO(73, 69, 79, 0.7)),
                                  hintText: "Firts name",
                                  fillColor:
                                      Color.fromRGBO(245, 245, 245, 0.6)),
                            ),
                          ),
                        ),
                        Expanded(
                          flex: 1,
                          child: Container(
                            margin: EdgeInsets.fromLTRB(2, 10, 0, 10),
                            child: TextFormField(
                              onTap: () {
                                setState(() {
                                  lasttName = 1;
                                });
                              },
                              controller: _controller3,
                              onChanged: (value) => setState(() {}),
                              decoration: InputDecoration(
                                  suffixIcon: _controller3.text.length > 0
                                      ? IconButton(
                                          onPressed: () {
                                            _controller3.clear();
                                            setState(() {});
                                          },
                                          icon: Icon(Icons.clear),
                                        )
                                      : null,
                                  enabledBorder: OutlineInputBorder(
                                      borderSide: validatetText(_controller3
                                                  .text
                                                  .toString()) ||
                                              lasttName == 0
                                          ? BorderSide.none
                                          : BorderSide(
                                              color: Colors.redAccent,
                                              width: 2)),
                                  border: OutlineInputBorder(
                                      borderSide: validatetText(_controller3
                                                  .text
                                                  .toString()) ||
                                              lasttName == 0
                                          ? BorderSide(
                                              color: Colors.blueAccent,
                                              width: 2)
                                          : BorderSide(
                                              color: Colors.redAccent,
                                              width: 2)),
                                  filled: true,
                                  hintStyle: TextStyle(
                                      color: Color.fromRGBO(73, 69, 79, 0.7)),
                                  hintText: "Last name",
                                  fillColor:
                                      Color.fromRGBO(245, 245, 245, 0.6)),
                            ),
                          ),
                        )
                      ],
                    ),
                  ),
                  Container(
                    child: TextFormField(
                      controller: _controller,
                      onChanged: (value) => setState(() {}),
                      onTap: () {
                        setState(() {
                          emailClick = 1;
                        });
                      },
                      decoration: InputDecoration(
                          suffixIcon: _controller.text.length > 0
                              ? IconButton(
                                  onPressed: () {
                                    _controller.clear();
                                    setState(() {});
                                  },
                                  icon: Icon(Icons.clear),
                                )
                              : null,
                          enabledBorder: OutlineInputBorder(
                              borderSide:
                                  validateEmail(_controller.text.toString()) ||
                                          emailClick == 0
                                      ? BorderSide.none
                                      : BorderSide(
                                          color: Colors.redAccent, width: 2)),
                          border: OutlineInputBorder(
                              borderSide:
                                  validateEmail(_controller.text.toString()) ||
                                          emailClick == 0
                                      ? BorderSide(
                                          color: Colors.blueAccent, width: 2)
                                      : BorderSide(
                                          color: Colors.redAccent, width: 2)),
                          hintStyle:
                              TextStyle(color: Color.fromRGBO(73, 69, 79, 0.7)),
                          hintText: "Email",
                          filled: true,
                          fillColor: Color.fromRGBO(245, 245, 245, 0.6)),
                    ),
                    margin: EdgeInsets.fromLTRB(0, 10, 0, 10),
                  ),
                  Container(
                    child: TextFormField(
                      onTap: () {
                        setState(() {
                          password = 1;
                        });
                      },
                      controller: _controller1,
                      obscureText: passwordvisible,
                      decoration: InputDecoration(
                          suffixIcon: IconButton(
                            onPressed: () {
                              setState(() {
                                if (passwordvisible == true) {
                                  passwordvisible = false;
                                } else {
                                  passwordvisible = true;
                                }
                              });
                            },
                            icon: Icon(passwordvisible == true
                                ? Icons.visibility
                                : Icons.visibility_off),
                          ),
                          enabledBorder: OutlineInputBorder(
                              borderSide:
                                  _controller1.text.length > 7 || password == 0
                                      ? BorderSide.none
                                      : BorderSide(
                                          color: Colors.redAccent, width: 2)),
                          border: OutlineInputBorder(
                              borderSide:
                                  _controller1.text.length > 7 || password == 0
                                      ? BorderSide(
                                          color: Colors.blueAccent, width: 2)
                                      : BorderSide(
                                          color: Colors.redAccent, width: 2)),
                          filled: true,
                          hintStyle:
                              TextStyle(color: Color.fromRGBO(73, 69, 79, 0.7)),
                          hintText: "Password",
                          fillColor: Color.fromRGBO(245, 245, 245, 0.6)),
                    ),
                    margin: EdgeInsets.fromLTRB(0, 10, 0, 10),
                  ),
                  Container(
                    child: TextFormField(
                      controller: _controller4,
                      obscureText: passwordvisible,
                      onTap: () {
                        setState(() {
                          resetPasword = 1;
                        });
                      },
                      decoration: InputDecoration(
                          suffixIcon: IconButton(
                            onPressed: () {
                              setState(() {
                                if (passwordvisible == true) {
                                  passwordvisible = false;
                                } else {
                                  passwordvisible = true;
                                }
                              });
                            },
                            icon: Icon(passwordvisible == true
                                ? Icons.visibility
                                : Icons.visibility_off),
                          ),
                          enabledBorder: OutlineInputBorder(
                              borderSide: (_controller1.text.toString() ==
                                          _controller4.text.toString()) ||
                                      resetPasword == 0
                                  ? BorderSide.none
                                  : BorderSide(
                                      color: Colors.redAccent, width: 2)),
                          border: OutlineInputBorder(
                              borderSide: (_controller1.text.toString() ==
                                          _controller4.text.toString()) ||
                                      resetPasword == 0
                                  ? BorderSide(
                                      color: Colors.blueAccent, width: 2)
                                  : BorderSide(
                                      color: Colors.redAccent, width: 2)),
                          filled: true,
                          hintStyle:
                              TextStyle(color: Color.fromRGBO(73, 69, 79, 0.7)),
                          hintText: "Reset password",
                          fillColor: Color.fromRGBO(245, 245, 245, 0.6)),
                    ),
                    margin: EdgeInsets.fromLTRB(0, 10, 0, 10),
                  ),
                  Container(
                    margin: EdgeInsets.fromLTRB(0, 10, 0, 10),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                          child: Row(
                            children: [
                              Checkbox(
                                value: checkbox,
                                onChanged: (value) {
                                  setState(() {
                                    if (checkbox == true) {
                                      checkbox = false;
                                    } else {
                                      checkbox = true;
                                    }
                                  });
                                },
                              ),
                              Text(
                                "Save account",
                                style: TextStyle(
                                    color: Color.fromRGBO(73, 69, 79, 0.7)),
                              )
                            ],
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.fromLTRB(0, 10, 0, 10),
                          child: GestureDetector(
                            onTap: () {},
                            child: new Text(
                              "Forget password?",
                              style: TextStyle(
                                  color: Color.fromRGBO(73, 69, 79, 0.7)),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    width: double.infinity,
                    margin: EdgeInsets.fromLTRB(0, 10, 0, 10),
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                          padding: const EdgeInsets.fromLTRB(0, 20, 0, 20)),
                      onPressed: () => signup(),
                      child: Text("sign up"),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.fromLTRB(0, 10, 0, 10),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          "Don't you have account?",
                          style:
                              TextStyle(color: Color.fromRGBO(73, 69, 79, 0.7)),
                        ),
                        Container(
                          margin: EdgeInsets.fromLTRB(7, 0, 0, 0),
                          child: GestureDetector(
                            onTap: () {
                              Navigator.pushNamed(context, "/signin");
                            },
                            child: new Text(
                              "Sign in",
                              style: TextStyle(
                                  color: Color.fromRGBO(30, 64, 138, 1)),
                            ),
                          ),
                        )
                      ],
                    ),
                  )
                ],
              ),
            ),
          ),
        ));
  }
}
